from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                            QLabel, QLineEdit, QCheckBox, QRadioButton,
                            QComboBox, QSlider, QProgressBar, QGroupBox)
from PyQt5.QtCore import Qt, QTimer

class BasicTab(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        layout = QVBoxLayout()
        
        # 1. Группа кнопок
        btn_group = QGroupBox("Кнопки и события")
        btn_layout = QHBoxLayout()
        
        self.btn1 = QPushButton("Кнопка 1")
        self.btn1.clicked.connect(self.on_button_click)
        
        self.btn2 = QPushButton("Кнопка 2")
        self.btn2.clicked.connect(self.on_button_click)
        
        btn_layout.addWidget(self.btn1)
        btn_layout.addWidget(self.btn2)
        btn_group.setLayout(btn_layout)
        layout.addWidget(btn_group)
        
        # 2. Текстовые элементы
        text_group = QGroupBox("Текстовые поля")
        text_layout = QVBoxLayout()
        
        self.label = QLabel("Текст будет меняться")
        self.line_edit = QLineEdit("Введите текст...")
        self.line_edit.textChanged.connect(self.on_text_changed)
        
        text_layout.addWidget(self.label)
        text_layout.addWidget(self.line_edit)
        text_group.setLayout(text_layout)
        layout.addWidget(text_group)
        
        # 3. Элементы выбора
        choice_group = QGroupBox("Элементы выбора")
        choice_layout = QHBoxLayout()
        
        # Чекбоксы
        self.checkbox = QCheckBox("Активировать функцию")
        self.checkbox.stateChanged.connect(self.on_checkbox_changed)
        
        # Радиокнопки
        self.radio1 = QRadioButton("Вариант 1")
        self.radio2 = QRadioButton("Вариант 2")
        self.radio1.toggled.connect(self.on_radio_toggled)
        
        # Выпадающий список
        self.combo = QComboBox()
        self.combo.addItems(["Пункт 1", "Пункт 2", "Пункт 3"])
        self.combo.currentIndexChanged.connect(self.on_combo_changed)
        
        choice_layout.addWidget(self.checkbox)
        choice_layout.addWidget(self.radio1)
        choice_layout.addWidget(self.radio2)
        choice_layout.addWidget(self.combo)
        choice_group.setLayout(choice_layout)
        layout.addWidget(choice_group)
        
        # 4. Прогресс и слайдер
        progress_group = QGroupBox("Прогресс-бар")
        progress_layout = QVBoxLayout()
        
        self.progress = QProgressBar()
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 100)
        self.slider.valueChanged.connect(self.progress.setValue)
        
        # Таймер для авто-прогресса
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_progress)
        self.timer.start(100)
        
        progress_layout.addWidget(self.progress)
        progress_layout.addWidget(self.slider)
        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)
        
        self.setLayout(layout)
    
    def on_button_click(self):
        sender = self.sender()
        self.parent.status_bar.showMessage(f"Нажата {sender.text()}")
        self.label.setText(f"Нажата: {sender.text()}")
    
    def on_text_changed(self, text):
        self.label.setText(f"Вы ввели: {text}")
    
    def on_checkbox_changed(self, state):
        text = "включено" if state == Qt.Checked else "выключено"
        self.parent.status_bar.showMessage(f"Чекбокс {text}")
    
    def on_radio_toggled(self):
        if self.radio1.isChecked():
            self.parent.status_bar.showMessage("Выбран вариант 1")
        else:
            self.parent.status_bar.showMessage("Выбран вариант 2")
    
    def on_combo_changed(self, index):
        self.parent.status_bar.showMessage(f"Выбран пункт {index+1}")
    
    def update_progress(self):
        if self.progress.value() >= 100:
            self.timer.stop()
        else:
            self.progress.setValue(self.progress.value() + 1)