from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QStatusBar, QMenuBar, 
                            QMenu, QAction, QMessageBox)
from basic_tab import BasicTab
from interaction_tab import InteractionTab
from dynamic_tab import DynamicTab
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Лабораторная работа 1 - Полная версия")
        self.setGeometry(100, 100, 1000, 800)
        
        # Создаем меню
        menubar = self.menuBar()
        file_menu = menubar.addMenu("Файл")
        
        exit_action = QAction("Выход", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Статус бар
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Готово")
        
        # Вкладки
        self.tab_widget = QTabWidget()
        self.setCentralWidget(self.tab_widget)
        
        # Добавляем вкладки
        self.tab_widget.addTab(BasicTab(self), "Основные компоненты")
        self.tab_widget.addTab(InteractionTab(self), "Взаимодействие")
        self.tab_widget.addTab(DynamicTab(self), "Динамические элементы")
        
        # Обработчики событий окна
        self.setMouseTracking(True)
        
    def mouseMoveEvent(self, event):
        self.status_bar.showMessage(f"Координаты мыши: {event.x()}, {event.y()}")
        
    def closeEvent(self, event):
        reply = QMessageBox.question(
            self, 'Выход',
            'Вы уверены, что хотите закрыть окно?',
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()