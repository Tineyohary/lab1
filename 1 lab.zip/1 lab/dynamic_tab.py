from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                            QLabel, QGroupBox, QScrollArea)
from PyQt5.QtCore import Qt, QPoint
from PyQt5.QtGui import QCursor

class DynamicTab(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        self.setMouseTracking(True)
        
        main_layout = QVBoxLayout()
        
        # 1. Управляющие кнопки
        control_group = QGroupBox("Управление")
        control_layout = QHBoxLayout()
        
        self.create_btn = QPushButton("Создать элемент")
        self.create_btn.clicked.connect(self.create_element)
        
        self.clear_btn = QPushButton("Очистить все")
        self.clear_btn.clicked.connect(self.clear_elements)
        
        self.counter_label = QLabel("Создано элементов: 0")
        
        control_layout.addWidget(self.create_btn)
        control_layout.addWidget(self.clear_btn)
        control_layout.addWidget(self.counter_label)
        control_group.setLayout(control_layout)
        main_layout.addWidget(control_group)
        
        # 2. Область для динамических элементов
        self.scroll_area = QScrollArea()
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        
        self.scroll_area.setWidget(self.scroll_content)
        self.scroll_area.setWidgetResizable(True)
        
        main_layout.addWidget(self.scroll_area)
        self.setLayout(main_layout)
        
        self.elements = []
        self.counter = 0
    
    def create_element(self):
        self.counter += 1
        btn = QPushButton(f"Элемент {self.counter}")
        btn.clicked.connect(lambda: self.on_element_click(btn))
        self.scroll_layout.addWidget(btn)
        self.elements.append(btn)
        self.update_counter()
        self.parent.status_bar.showMessage(f"Создан элемент {self.counter}")
    
    def clear_elements(self):
        for element in self.elements:
            element.deleteLater()
        self.elements = []
        self.counter = 0
        self.update_counter()
        self.parent.status_bar.showMessage("Все элементы удалены")
    
    def on_element_click(self, element):
        self.parent.status_bar.showMessage(f"Нажат: {element.text()}")
        element.setStyleSheet("background-color: lightblue;")
    
    def update_counter(self):
        self.counter_label.setText(f"Создано элементов: {self.counter}")
    
    def mousePressEvent(self, event):
        if event.button() == Qt.RightButton:
            self.create_at_position(event.pos())
    
    def create_at_position(self, pos):
        self.counter += 1
        btn = QPushButton(f"Позиция {self.counter}", self)
        btn.move(pos.x() - 50, pos.y() - 15)
        btn.show()
        btn.clicked.connect(lambda: self.on_element_click(btn))
        self.elements.append(btn)
        self.update_counter()
        self.parent.status_bar.showMessage(f"Создан элемент в позиции ({pos.x()}, {pos.y()})")