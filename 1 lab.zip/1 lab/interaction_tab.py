from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QListWidget,
                            QPushButton, QLabel, QGroupBox, QMessageBox)

class InteractionTab(QWidget):
    def __init__(self, parent):
        super().__init__()
        self.parent = parent
        layout = QVBoxLayout()
        
        # 1. Список и управление
        list_group = QGroupBox("Управление списком")
        list_layout = QHBoxLayout()
        
        self.list_widget = QListWidget()
        self.list_widget.addItems(["Элемент 1", "Элемент 2", "Элемент 3"])
        self.list_widget.itemClicked.connect(self.on_list_item_clicked)
        
        btn_layout = QVBoxLayout()
        self.add_btn = QPushButton("Добавить")
        self.add_btn.clicked.connect(self.add_item)
        
        self.remove_btn = QPushButton("Удалить")
        self.remove_btn.clicked.connect(self.remove_item)
        
        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.remove_btn)
        
        list_layout.addWidget(self.list_widget)
        list_layout.addLayout(btn_layout)
        list_group.setLayout(list_layout)
        layout.addWidget(list_group)
        
        # 2. Взаимодействие элементов
        interact_group = QGroupBox("Взаимодействие элементов")
        interact_layout = QVBoxLayout()
        
        self.toggle_label = QLabel("Состояние: выключено")
        self.toggle_btn = QPushButton("Включить взаимодействие")
        self.toggle_btn.clicked.connect(self.toggle_interaction)
        
        interact_layout.addWidget(self.toggle_label)
        interact_layout.addWidget(self.toggle_btn)
        interact_group.setLayout(interact_layout)
        layout.addWidget(interact_group)
        
        self.setLayout(layout)
    
    def on_list_item_clicked(self, item):
        self.parent.status_bar.showMessage(f"Выбран: {item.text()}")
    
    def add_item(self):
        count = self.list_widget.count() + 1
        self.list_widget.addItem(f"Новый элемент {count}")
        self.parent.status_bar.showMessage(f"Добавлен элемент {count}")
    
    def remove_item(self):
        if self.list_widget.currentItem():
            item = self.list_widget.takeItem(self.list_widget.currentRow())
            self.parent.status_bar.showMessage(f"Удален: {item.text()}")
    
    def toggle_interaction(self):
        if self.toggle_btn.text() == "Включить взаимодействие":
            self.toggle_btn.setText("Выключить взаимодействие")
            self.toggle_label.setText("Состояние: включено")
            self.list_widget.setStyleSheet("background-color: lightgreen;")
        else:
            self.toggle_btn.setText("Включить взаимодействие")
            self.toggle_label.setText("Состояние: выключено")
            self.list_widget.setStyleSheet("")